export async function GET() {
  // This is a placeholder. In production, check session/token
  return Response.json({
    id: "1",
    email: "user@university.edu",
    name: "John Doe",
  })
}
